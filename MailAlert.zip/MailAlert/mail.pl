#!/usr/bin/perl

 $to = 'aditya.saxena@prudential.com.sg,pradyuman.Singh@prudential.com.sg,Sangamesh.Gugwad@prudential.com.sg,Yogesh.Gaikwad@prudential.com.sg,Mayank.Singhal@wedopulse.co.in,pulse-support@accoliteindia.com';
 $cc = 'Avi.Baraswal@prudential.com.sg,Ashishkumar.Joshi@prudential.com.sg,Nitish.Kumar@prudential.com.sg,Punya.Sahoo@prudential.com.sg,Avinash.Singh@prudential.com.sg,arvind.kumar@prudential.com.sg,Partha.Sarathy.Baytha@prudential.com.sg,SameerKumar.Singh@prudential.com.sg';
 $from = 'SG_ReportUser@prudential.com.sg';
 $subject = 'Hourly Report - SG Prod';
 $message = '<p>Hi All,<br>Please find below the report for SG prod servers on 2020-10-20 from 14:00 to 15:00 IST.</p>
 <br>
 <table border=1 style="border-collapse: collapse;padding: 2px"> 
 <tr><th>POD</th><th>Allocated CPUs</th><th>Max CPU Usage</th><th>Allocated RAM</th><th>Max RAM Usage</th><th>Allocated Heap</th><th>Max Heap Used</th></tr>
<tr align="center"><td>FLINK-JM-0</td><td>8</td><td style="background-color: #008000" >0.065</td><td>7.812</td><td style="background-color: #008000" >3.436</td><td>3.996</td><td style="background-color: #008000">0.772</td></tr>
<tr align="center"><td>FLINK-TM-0</td><td>16</td><td style="background-color: #008000" >0.038</td><td>32</td><td style="background-color: #008000" >9.971</td><td>22.99</td><td style="background-color: #008000">6.430</td></tr>
<tr align="center"><td>FLINK-TM-1</td><td>16</td><td style="background-color: #008000" >0.462</td><td>32</td><td style="background-color: #FFFF00" >28.45</td><td>22.95</td><td style="background-color: #008000">8.724</td></tr>
<tr align="center"><td>COUCHBASE-CLUSTER-0000</td><td>24</td><td style="background-color: #008000" >1.418</td><td>62.5</td><td style="background-color: #008000" >9.781</td><td></td><td style="background-color: #008000"></td></tr>
<tr align="center"><td>COUCHBASE-CLUSTER-0008</td><td>24</td><td style="background-color: #008000" >0.590</td><td>31.25</td><td style="background-color: #008000" >14.71</td><td></td><td style="background-color: #008000"></td></tr>
<tr align="center"><td>COUCHBASE-CLUSTER-0010</td><td>24</td><td style="background-color: #008000" >0.420</td><td>31.25</td><td style="background-color: #008000" >5.363</td><td></td><td style="background-color: #008000"></td></tr>
<tr align="center"><td>KAFKA-0</td><td>8</td><td style="background-color: #008000" >0.125</td><td>15.62</td><td style="background-color: #FF0000" >15.18</td><td>4</td><td style="background-color: #008000">1.199</td></tr>
<tr align="center"><td>KAFKA-1</td><td>8</td><td style="background-color: #008000" >0.085</td><td>15.62</td><td style="background-color: #008000" >4.315</td><td>4</td><td style="background-color: #008000">1.391</td></tr>
<tr align="center"><td>KAFKA-2</td><td>8</td><td style="background-color: #008000" >0.094</td><td>15.62</td><td style="background-color: #008000" >4.525</td><td>4</td><td style="background-color: #008000">3.147</td></tr>
<tr align="center"><td>ZOOKEEPER-0</td><td>4</td><td style="background-color: #008000" >0.004</td><td>7.812</td><td style="background-color: #008000" >0.973</td><td>1.998</td><td style="background-color: #008000">0.258</td></tr>
<tr align="center"><td>ZOOKEEPER-1</td><td>4</td><td style="background-color: #008000" >0.006</td><td>7.812</td><td style="background-color: #008000" >1.016</td><td>1.998</td><td style="background-color: #008000">0.064</td></tr>
<tr align="center"><td>ZOOKEEPER-2</td><td>4</td><td style="background-color: #008000" >0.004</td><td>7.812</td><td style="background-color: #008000" >1.011</td><td>1.998</td><td style="background-color: #008000">0.250</td></tr>
 </table><br> 
 <table style="cellspacing: 25px"><td> <table border=1 style="border-collapse: collapse;padding: 2px">
 <tr><th>PVC Name</th><th>Allocated Storage</th><th>Used Storage</th></tr>
  
<tr><td>datadir-flink-jm-0</td><td>1007.8</td><td style="background-color: #008000">0.1399</td></tr>
<tr><td>datadir-flink-tm-0</td><td>1007.8</td><td style="background-color: #008000">1.3590</td></tr>
<tr><td>datadir-flink-tm-1</td><td>1007.8</td><td style="background-color: #008000">1.1972</td></tr>
<tr><td>datadir-kafka-0</td><td>1007.8</td><td style="background-color: #008000">2.9250</td></tr>
<tr><td>datadir-kafka-1</td><td>1007.8</td><td style="background-color: #008000">2.2275</td></tr>
<tr><td>datadir-kafka-2</td><td>1007.8</td><td style="background-color: #008000">2.0632</td></tr>
<tr><td>zookeeperdata-zookeeper-0</td><td>503.84</td><td style="background-color: #008000">2.5510</td></tr>
<tr><td>zookeeperdata-zookeeper-1</td><td>503.84</td><td style="background-color: #008000">2.5549</td></tr>
<tr><td>zookeeperdata-zookeeper-2</td><td>503.84</td><td style="background-color: #008000">2.5513</td></tr>
 </table></td><td></td><td></td>
<td> <table border=1 style="border-collapse: collapse;padding: 7px"><tr><th>Bucket Name</th><th>Max Ops (Last hour)</th></tr> 
<tr><td>content_public</td><td>0</td></tr>
<tr><td>content</td><td>0</td></tr>
<tr><td>dataALL</td><td>0</td></tr>
<tr><td>data</td><td>3</td></tr>
<tr><td>schema</td><td>30</td></tr>

</table></td></table>
 <p>Regards,<br>Triage-Team</p/>';

  open(MAIL, "|/usr/sbin/sendmail -t");

   # Email Header
   print MAIL "To: $to\n";
   print MAIL "Cc: $cc\n";
   print MAIL "From: $from\n";
   print MAIL "Subject: $subject\n";
   print MAIL "Content-Type: text/html\n";

   # Email Body
   print MAIL $message;

   close(MAIL);
  
