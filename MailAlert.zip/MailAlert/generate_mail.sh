CUR_PATH=/home/346771/PRO_REPORT/SG
echo "#!/usr/bin/perl

 \$to = 'aditya.saxena@prudential.com.sg,pradyuman.Singh@prudential.com.sg,Sangamesh.Gugwad@prudential.com.sg,Yogesh.Gaikwad@prudential.com.sg,Mayank.Singhal@wedopulse.co.in,pulse-support@accoliteindia.com';
 \$cc = 'Avi.Baraswal@prudential.com.sg,Ashishkumar.Joshi@prudential.com.sg,Nitish.Kumar@prudential.com.sg,Punya.Sahoo@prudential.com.sg,Avinash.Singh@prudential.com.sg,arvind.kumar@prudential.com.sg,Partha.Sarathy.Baytha@prudential.com.sg,SameerKumar.Singh@prudential.com.sg';
 \$from = 'SG_ReportUser@prudential.com.sg';
 \$subject = 'Hourly Report - SG Prod';
 \$message = '<p>Hi All,<br>Please find below the report for SG prod servers on `date -d "150 minutes ago" +%F` from `date -d "210 minutes ago" +%T | cut -d":" -f1-2` to `date -d "150 minutes ago" +%T | cut -d":" -f1-2` IST.</p>
 <br>
 <table border=1 style=\"border-collapse: collapse;padding: 2px\"> 
 <tr><th>POD</th><th>Allocated CPUs</th><th>Max CPU Usage</th><th>Allocated RAM</th><th>Max RAM Usage</th><th>Allocated Heap</th><th>Max Heap Used</th></tr>" >${CUR_PATH}/mail.pl

function get_percent()
{
        v=`echo $1 $2 | awk '{div=$2/$1 * 100; printf"%0.2f\n", div }'`
        if (( $(echo $v | awk '{print ($1 < 80 )}' ) ))
        then
                co="#008000"
        elif (( $(echo $v | awk '{print ($1 < 90 )}' ) ))
        then
                co="#FFFF00"
        else
                co="#FF0000"
        fi
	echo $co
}

 while read i
 do
 temp=`echo $i | awk '{print $1}'`
 n=`cat ${CUR_PATH}/mem.txt |  sed 's/{/\n/g'  | grep pod | egrep "$temp" | tr '"' ' ' |sort -nr -t',' -k3 | awk '{print $3}'| head -1`
 #tot_cpu=`echo $i |  awk '{print $3}'`
 tot_cpu=`cat ${CUR_PATH}/allocated_cpu.txt | sed 's/{/\n/g' | grep $n | cut -d":" -f3 | cut -d'"' -f2 | cut -c1-5`
 used_cpu=`cat ${CUR_PATH}/cpu.txt | sed 's/{/\n/g' | grep $n | cut -d":" -f3 | cut -d'"' -f2 | cut -c1-5`
 if [ -Z ${used_cpu} ]
 then
 	echo "Values not fetched::`date`" >>${CUR_PATH}/fetch_result.txt
	exit
 fi
 #tot_mem=`echo $i |  awk '{print $2}'`
 tot_mem=`cat ${CUR_PATH}/allocated_ram.txt | sed 's/{/\n/g' | grep $n | cut -d":" -f3 | cut -d'"' -f2 | cut -c1-5`
 used_mem=`cat ${CUR_PATH}/mem.txt | sed 's/{/\n/g' | grep $n | cut -d":" -f3 | cut -d'"' -f2 | cut -c1-5`
 #tot_heap=`echo $i | awk '{print $4}'`
 tot_heap=`cat ${CUR_PATH}/allocated_heap.txt | sed 's/{/\n/g' | grep $n | cut -d":" -f3 | cut -d'"' -f2 | cut -c1-5`
 used_heap=`cat ${CUR_PATH}/all_heap.txt | sed 's/{/\n/g' | grep $n | cut -d":" -f3 | cut -d'"' -f2 | cut -c1-5`
 echo "<tr align=\"center\"><td>`echo $n | tr [:lower:] [:upper:]`</td><td>${tot_cpu}</td><td style=\"background-color: `get_percent ${tot_cpu} ${used_cpu}`\" >${used_cpu}</td><td>${tot_mem}</td><td style=\"background-color: `get_percent ${tot_mem} ${used_mem}`\" >${used_mem}</td><td>${tot_heap}</td><td style=\"background-color: `get_percent ${tot_heap} ${used_heap}`\">${used_heap}</td></tr>" >>${CUR_PATH}/mail.pl
 done < ${CUR_PATH}/pod.txt
 echo " </table><br> 
 <table style=\"cellspacing: 25px\"><td> <table border=1 style=\"border-collapse: collapse;padding: 2px\">
 <tr><th>PVC Name</th><th>Allocated Storage</th><th>Used Storage</th></tr>
  " >> ${CUR_PATH}/mail.pl
for i in `cat ${CUR_PATH}/pvc.txt`
do
	tot_sto=`cat ${CUR_PATH}/total_storage.txt | sed 's/{/\n/g' | grep $i | cut -d":" -f3 | cut -d'"' -f2 | cut -c1-6`
	used_sto=`cat ${CUR_PATH}/usage_storage.txt | sed 's/{/\n/g' | grep $i | cut -d":" -f3 | cut -d'"' -f2 | cut -c1-6`
	if [[ "$i" == "couchbase"* ]] || [[ "$i" == "flink-shared-state" ]] || [[ "$i" == "deployable"* ]] || [[ "$i" == *"cms-cache"*   ]] || [[ "$i" == *"backup"*  ]]
	then
		get_percent ${tot_sto} ${used_sto}
		if (( $(echo $v | awk '{print ($1 > 60 )}' ) ))
		then 	
			echo "<tr><td>$i</td><td>${tot_sto}</td><td style=\"background-color: `get_percent ${tot_sto} ${used_sto}`\">${used_sto}</td></tr>" >>${CUR_PATH}/mail.pl
		fi
	else 
		echo "<tr><td>$i</td><td>${tot_sto}</td><td style=\"background-color: `get_percent ${tot_sto} ${used_sto}`\">${used_sto}</td></tr>" >>${CUR_PATH}/mail.pl
	fi
done
echo " </table></td><td></td><td></td>
<td> <table border=1 style=\"border-collapse: collapse;padding: 7px\"><tr><th>Bucket Name</th><th>Max Ops (Last hour)</th></tr> " >>${CUR_PATH}/mail.pl
for i in `cat ${CUR_PATH}/ops.txt |  sed 's/{/\n/g' | grep bucket | sort`
do
	bname=`echo $i | tr '"' ' ' | awk '{print $3}'`
	opv=`echo $i | tr '"' ' ' | awk '{print $7}'`
	echo "<tr><td>${bname}</td><td>${opv}</td></tr>" >>  ${CUR_PATH}/mail.pl
done 
echo "
</table></td></table>
 <p>Regards,<br>Triage-Team</p/>';

  open(MAIL, \"|/usr/sbin/sendmail -t\");

   # Email Header
   print MAIL \"To: \$to\\n\";
   print MAIL \"Cc: \$cc\\n\";
   print MAIL \"From: \$from\\n\";
   print MAIL \"Subject: \$subject\\n\";
   print MAIL \"Content-Type: text/html\\n\";

   # Email Body
   print MAIL \$message;

   close(MAIL);
  " >>${CUR_PATH}/mail.pl
chmod 755 ${CUR_PATH}/mail.pl
perl ${CUR_PATH}/mail.pl
rm -f mail.pl
