echo "This script is called $1 $2" >/LAJBIUT/NAVEEN/HELP/RESIN/text.txt
