#
# Database for the basic example
#
DROP TABLE servlet_courses;
CREATE TABLE servlet_courses (
  course VARCHAR(250) NOT NULL,
  teacher VARCHAR(250),

  PRIMARY KEY(course)
);

INSERT INTO servlet_courses VALUES('Potions', 'Severus Snape');
INSERT INTO servlet_courses VALUES('Transfiguration', 'Minerva McGonagall');
INSERT INTO servlet_courses VALUES('Charms', 'Filius Flitwick');
INSERT INTO servlet_courses VALUES('Defense against the Dark Arts', 'Remus Lupin');
INSERT INTO servlet_courses VALUES('Divination', 'Sybil Trelawney');
