#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <memory.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <jni.h>

#include "cse.h"
#include "resin.h"

int
ssl_create(server_socket_t *ss, ssl_config_t *config)
{
  return 0;
}

jint
Java_com_caucho_vfs_QJniSocket_getClientCert(JNIEnv *env,
                                             jobject obj,
                                             jint fd,
                                             jbyteArray buf,
                                             jint offset,
                                             jint length)
{
  return 0;
}
