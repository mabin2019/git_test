#if !defined(AFX_IIS_SRUN_H__44338CF7_365D_11D3_A4E0_00A0CC21D9DE__INCLUDED_)
#define AFX_IIS_SRUN_H__44338CF7_365D_11D3_A4E0_00A0CC21D9DE__INCLUDED_

// IIS_SRUN.H - Header file for your Internet Server
//    iis_srun Extension

#include "resource.h"
/*
class CIis_srunExtension : public CHttpServer
{
public:
	CIis_srunExtension();
	~CIis_srunExtension();

// Overrides
	// ClassWizard generated virtual function overrides
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//{{AFX_VIRTUAL(CIis_srunExtension)
	public:
	virtual BOOL GetExtensionVersion(HSE_VERSION_INFO* pVer);
	//}}AFX_VIRTUAL
	virtual BOOL TerminateExtension(DWORD dwFlags);

	// TODO: Add handlers for your commands here.
	// For example:

	//void Default(CHttpServerContext* pCtxt);
	DWORD CIis_srunExtension::HttpExtensionProc(EXTENSION_CONTROL_BLOCK *pECB);

	struct config_t *config;

	//DECLARE_PARSE_MAP()

	//{{AFX_MSG(CIis_srunExtension)
	//}}AFX_MSG
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
*/
#endif // !defined(AFX_IIS_SRUN_H__44338CF7_365D_11D3_A4E0_00A0CC21D9DE__INCLUDED)
