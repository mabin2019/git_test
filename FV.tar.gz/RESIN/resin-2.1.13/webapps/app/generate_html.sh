#!/bin/sh
CUR_PATH=`pwd`
sh $CUR_PATH/HTML_GENERATION/generate_html_pstack.sh
sh $CUR_PATH/HTML_GENERATION/generate_html_logs.sh
sh $CUR_PATH/HTML_GENERATION/generate_html_user_creation.sh
sh $CUR_PATH/HTML_GENERATION/generate_html_user_unlock.sh                  
sh $CUR_PATH/HTML_GENERATION/generate_html_holiday.sh
