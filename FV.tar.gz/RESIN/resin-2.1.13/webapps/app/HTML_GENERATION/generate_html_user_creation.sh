#!/bin/sh
CUR_PATH=`pwd`
cd /etc/b2k
i=0
count=`ls -lrt | grep drwx | grep -v setup | wc -l`
while [ $count -gt 0 ]
do
	a[$i]=`ls -lrt | grep drwx | grep -v setup |awk '{print $9}' | tr -d "/" | head -${count} | tail -1`
	count=$((count-1))
	i=$((i+1))
done
echo "
<!DOCTYPE html>
<html>
<head>
<title> User Creation Page </title>
<link rel=\"stylesheet\" href=\"master_css.css\" type=\"text/css\" />
</head>
<form name=\"form\" action=\"usercreation.jsp\" method=\"post\">
<body>
<div id=\"heading\">
        <div id=\"hcontent\">User Creation Page</div>
        <!--<div id=\"hoption\"><a href=\"index.html\"><img src=\"images/home5.gif\" alt=\"Home\" height=\"40\" width=\"40\"></a></div>-->
        <div id=\"hoption\"><a href=\"index.html\"><img src=\"images/home4.gif\" alt=\"Home\" height=\"40\" width=\"110\"></a></div>
</div>
<div id=\"subcontent\">
<h3>Please enter the below details:</h3>
<hr>
<table align=\"center\">
<tr>

<td align=\"right\">Area Install ID:</td>
<td align=\"left\">
<select name=\"txt1\" style= \"width: 148px\" >
	<option value=\"\">--Select--</option>" >$CUR_PATH/UserCreation.html
	for i in ${a[@]}
	do
		echo "<option value=\"$i\">$i</option>" >>$CUR_PATH/UserCreation.html
	done
echo "</select></td>
</tr>
<tr>
<td align=\"right\">Existing User ID:</td>
<td align=\"left\"><input type=\"text\" name=\"txt2\" placeholder=\"Ex: UBSADMIN\"/></td>
</tr>
<tr>
<td align=\"right\">New User ID:</td>
<td align=\"left\"><input type=\"text\" name=\"txt3\" placeholder=\"Ex: 1234A\"/></td>
</tr>
<tr>
<td align=\"right\">Role ID:</td>
<td align=\"left\"><input type=\"text\" name=\"txt4\" placeholder=\"Ex: LOANS_ROLE\"/></td>
</tr>
<tr>
<td colspan=\"2\" align=\"center\">
	<input type=\"submit\" value=\"Submit\" onclick=\"return dosubmit()\"/>
	<input type=\"reset\" value=\"Clear\" onclick=\"return doclick()\"/>
</tr>
</table>
<marquee onmouseover=\"this.stop();\"onmouseout=\"this.start();\">**Please choose new user id to be employee_id&ltcharacter&gt</marquee>
<hr>
<script>

	function doclick()
	{	
		var iid=document.form.txt1.value;
		var iid1=document.form.txt2.value;
		var iid2=document.form.txt3.value;
		var iid3=document.form.txt4.value;
		if (((iid == \"\")||(iid==null)) && ((iid1 == \"\")||(iid1==null)) && ((iid2 == \"\")||(iid2==null)) && ((iid3 == \"\")||(iid3==null)))
		{
			alert(\"Nothing to clear\");
			return false;
		}
		else
		{
			var rval=confirm(\"Do you want the data to be cleared?\");
		if (rval == true)
		{
			alert(\"Data cleared\");
			return true;
		}	
		else
			return false;
		}
	}
	function dosubmit()
	{
		var iid=document.form.txt1.value;
		var iid1=document.form.txt2.value;
		var iid2=document.form.txt3.value;
		var iid3=document.form.txt4.value;
		if ((iid == \"\")||(iid==null))
		{
			alert(\"Please select any install id\");
			return false;
		}
		else if ((iid1 == \"\")||(iid1==null))
		{
			alert(\"Existing User ID is not entered\");
			return false;
		}
		else if ((iid2 == \"\")||(iid2==null))
		{
			alert(\"New User ID is not entered\");
			return false;
		}
		else if ((iid3 == \"\")||(iid3==null))
		{
			alert(\"Role ID is not entered\");
			return false;
		}
		else
		{
			var rval=confirm(\"Data entered is \nDBSID: \" +iid+ \"\nExisting user Id: \" +iid1+\"\nNew user Id: \" +iid2+\"\nRole Id: \" +iid3+\"\nContinue?	\");
			if (rval == true)
				return true;
			else 
				return false;
		}
	}
</script>
</div>
<br><br>
<div id=\"footer\">
                <div id=\"fcontent\" align=\"center\">LART Devops</div>
</div>
</body>
</form>
</html>
" >>$CUR_PATH/UserCreation.html
