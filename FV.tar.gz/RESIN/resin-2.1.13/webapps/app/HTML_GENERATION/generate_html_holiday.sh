#!/bin/sh
CUR_PATH=`pwd`
cd /etc/b2k
i=0
count=`ls -lrt | grep drwx | grep -v setup | wc -l`
while [ $count -gt 0 ]
do
        a[$i]=`ls -lrt | grep drwx | grep -v setup |awk '{print $9}' | tr -d "/" | head -${count} | tail -1`
        count=$((count-1))
        i=$((i+1))
done
echo "
<!DOCTYPE html>
<html>
<head>
<title>Calendar Add Page</title>
<link rel=\"stylesheet\" href=\"master_css.css\" type=\"text/css\" />
</head>
<form name=\"form\" action=\"holidayissue.jsp\" method=\"post\">
<body>
<div id=\"heading\">
        <div id=\"hcontent\">Calendar Add Page</div>
        <!--<div id=\"hoption\"><a href=\"index.html\"><img src=\"images/home5.gif\" alt=\"Home\" height=\"40\" width=\"40\"></a></div>-->
        <div id=\"hoption\"><a href=\"index.html\"><img src=\"images/home4.gif\" alt=\"Home\" height=\"40\" width=\"110\"></a></div>
</div>
<div id=\"subcontent\">
<h3>Please enter the below details:</h3>
<hr>
<table align=\"center\">
<tr>
<td align=\"right\">Area Install ID:</td>
<td align=\"left\">
<select name=\"txt1\" style= \"width: 148px\" >
<option value=\"\">--Select--</option>" >$CUR_PATH/CalendarAdd.html
for i in ${a[@]}
do
echo "<option value=\"$i\">$i</option>" >>$CUR_PATH/CalendarAdd.html
done
echo "
</select></td>
</tr>
<tr>
<td colspan=\"2\" align=\"center\">
        <input type =\"submit\" value=\"Submit\" name=\"submit\" onclick=\"return dosubmit()\"/>
        <input type =\"reset\" value=\"Clear\" name=\"reset\" onclick=\"return doclick()\"/>
</td>
</tr>
</table>
<hr>
<script>

        function doclick()
        {
                var iid=document.form.txt1.value;

                if (((iid == \"\")||(iid==null)))
                {
                        alert(\"Nothing to clear\");
                        return false;
                }
                else
                {
                        var rval=confirm(\"Do you want the data to be cleared?\");
                if (rval == true)
                {
                        alert(\"Data cleared\");
                        return true;
                }
                else
                        return false;
                }
        }
        function dosubmit()
        {
                var iid=document.form.txt1.value;
                if ((iid == \"\")||(iid==null))
                {
                        alert(\"Please select any install id\");
                        return false;
                }
                else
                {
                        var rval=confirm(\"Data entered is \nDBSID: \" +iid+\"\nContinue?\");
                        if (rval == true)
                                return true;
                        else
                                return false;
                }
        }
</script>
</div>
</div>
<br><br>
<marquee onmouseover=\"this.stop();\"onmouseout=\"this.start();\">**Page adds calendar for the present month. If any particular day to be changed, please check with team!</marquee>
<br><br>
<div id=\"footer\">
                <div id=\"fcontent\" align=\"center\">LART Devops</div>
</div>
</body>
</form>
</html>
" >>$CUR_PATH/CalendarAdd.html
