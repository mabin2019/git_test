function myFunction() {
var x,y,z;
x=5;
y="6";
z=x+y;
x=null;
str = "My Text is to sEe replace See also replace";
var res = str.replace(/see/gi,"rep");
	document.getElementById('demo').innerHTML = "My Function in file :"+ document.screenX;
	
	document.getElementById("demo").innerHTML = document.getElementById("demo").style.backgroundColor;
document.getElementById("demo").style.backgroundColor = "yellow";
str.slice
}

function myValidation() {
	var x = document.forms["myForm"]["fname"].value;
	if ( x == "") {
		alert("Name must be filled");
		return false;
	}
}
var id;
var score = 0;
function ju(){
alert("inside");
}
function jump() {
	var elem = document.getElementById("animate");
	score = score + 1;
	clearInterval(id);
	id = setInterval(frame,7);
	var cnt = 0;
	var pos=360;
	//var top = parseInt(window.getComputedStyle(elem).getPropertyValue('top').split('px')[0]);
	
	//var left = parseInt(window.getComputedStyle(elem).getPropertyValue('left').split('px')[0]); 
	var top = parseInt(elem.offsetTop);
	var left = parseInt(elem.offsetLeft);
	var X = event.clientX;
	var Y = event.clientY;
	var dir = 0;
	if(X > (left+20)) {
		dir = 1;
	}
	else {
		dir = 0;
	}
	//var cnt = parseInt(window.getComputedStyle(elem).getPropertyValue('top').split('px')[0]);
	//var t = parseInt(top);
	//alert(typeof cnt);
	//alert(top.split('px')[0]);
	//alert(elem.style.top);
	var left = 0;
	function frame() {
		//cnt = 0;
		//pos =0;
		//alert("hi");
		//document.getElementById("value").innerHTML = document.getElementById("value").innerHTML + cnt;
		document.getElementById("val").innerHTML = "Score: "+score;
		if((cnt <40)) {
			cnt++;
			//pos = parseInt(window.getComputedStyle(elem).getPropertyValue('top').split('px')[0]);
			//left = parseInt(window.getComputedStyle(elem).getPropertyValue('left').split('px')[0]);
			pos = parseInt(elem.offsetTop);
			left = parseInt(elem.offsetLeft);
			elem.style.top = (pos - 1) + 'px';
			if(cnt%2 == 0) {
				elem.style.left = (dir == 0)? ((left - 1)+'px') : ((left + 1) + 'px');
			}
			if(left == 550) {
				dir = 0;
			}
			else if(left == 0) {
				dir = 1;
			}
		} else if(pos < 360){
			//cnt++;
			//pos = parseInt(window.getComputedStyle(elem).getPropertyValue('top').split('px')[0]);
			pos = parseInt(elem.offsetTop);
			left = parseInt(elem.offsetLeft);
			elem.style.top = (pos + 1) + 'px';
			//left = parseInt(window.getComputedStyle(elem).getPropertyValue('left').split('px')[0]);
			if(pos%2 == 0) {
				elem.style.left = (dir == 0)? ((left - 1)+'px') : ((left + 1) + 'px');
			}
			if(left == 550) {
				dir = 0;
			}
			else if(left == 0) {
				dir = 1;
			}
		}
		else {
			alert("Game Over");
			var hs = parseInt(document.getElementById("hs").innerHTML.split(":")[1]);
			if(score > hs) {
				alert("High Score");
				document.getElementById("hs").innerHTML = "High Score: "+score;
			}
			//pos = parseInt(window.getComputedStyle(elem).getPropertyValue('top').split('px')[0]);
			pos = parseInt(elem.offsetTop);
			clearInterval(id);
			score = 0;
			return;
		}
		
		//document.getElementById("animate").addEventListner("click",jump);
		//alert(cnt);
		if(pos == 361) {
			//alert("down");
			//pos = parseInt(window.getComputedStyle(elem).getPropertyValue('top').split('px')[0]);
			//clearInterval(id);
			return;
			
		}
		
	}
	if(cnt >=360) {
		clearInterval(id);
		cnt = 0;
		return;
	}

}

function getCor(){
	document.getElementById("cor").innerHTML = "Cor : " + event.clientX +", "+event.clientY;
}

function myMove() {
	var elem = document.getElementById("animate");
	var pos = 0;
	var id = setInterval(frame,1);
	function frame() {
		if(pos == 360) {
			clearInterval(id);
		} else {
			pos++;
			elem.style.top = pos+'px';
			elem.style.left = pos+'px';
		}
	}
}



function checkCookies() {
    var text = "";
    if (navigator.cookieEnabled == true) {
        text = "Cookies are enabled.";
    } else {
        text = "Cookies are not enabled.";
    }
    document.getElementById("val").innerHTML = text;
}
