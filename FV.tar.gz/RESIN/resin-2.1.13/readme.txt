Copyright (c) 1998-2001 Caucho Technology. All Rights Reserved.

This is the README file for Resin(tm)
=====================================

The documentation included with Resin is in XTP format starting at
doc/ref/index.xtp with installation documentation at doc/ref/starting.xtp.

XTP assumes you've already got Resin working, so you should read this
README up to part III: Getting Started.  The full documentation is also
available online at http://www.caucho.com/products/resin/ref if you
have trouble getting started.

Questions should go to our mailing list.  To subscribe, send a mail to 
resin-interest-request@caucho.com with the body "subscribe".

You can also send us your bug reports to bugs@caucho.com


I) Licensing
------------

Resin 2.0 is released under the Caucho Developer Source License.  For
pricing and licensing information, see /sales.xtp.

 o You may use Resin for development, evaluation, and demos.
 o You must contact us for a deployment license if either:
   * You are paid to use Resin.
   * You are paying someone else to use Resin.
 o If no one is paid to use Resin, you may use Resin for deployment
   without purchasing a license:
   * students
   * private use
   * tiny startups with neither funding nor income.
 o Anyone falling in between should contact us for a waiver.
 o Distributors must contact us.
 o If you are allowed to use Resin, you may modify the source for that use.


II) Preconditions
-----------------

1) Resin needs a Java JDK before it can run.  Resin works with 
JDK 1.2 or greater.  You need the JDK, not the JRE because Resin needs the
Java compiler.  We recommend using IBM's jikes compiler.

Some locations for JDKs include:

  http://java.sun.com      -- Sun's site
  http://www.ibm.com       -- IBM's fast 1.3 JDKs.

2) On Unix, Resin's wrapper.pl script expects Perl 5.

3) On Windows, you'll need an unzip tool available at http://www.winzip.com


III) Getting Started
--------------------

Start your Resin evaluation with Resin's included httpd server
even if you plan to use Resin with another web server.

The included HTTP/1.1 server makes it easy to evaluate Resin, JSP
and servlets.  Just start it up.  The default configuration
files can be used without modification.

1) To start the server:

     unix> resin-2.0/bin/httpd.sh

   or

     c:\> resin-2.0/bin/httpd

   The server listens to port 8080.

2) Usually, Resin can find the JDK, but you may need to set JAVA_HOME in some
   configurations.  You can also specify the JDK on the command line:

   unix> resin-2.0/bin/httpd.sh -java_home /usr/java

   Starting Resin with -verbose is a great way to see what environment
   Resin is running.

3) Browse http://localhost:8080 or equivalently http://127.0.0.1:8080.

4) Go through the tutorial at http://localhost:8080/java_tut.

5) Run through the demos at http://localhost:8080/examples

6) For JSP, create test.jsp in resin-2.0/doc/test.jsp and browse
   http://localhost:8080/test.jsp.

   Resin serves files from resin2.0/doc in the default configuration.
   All files with the extension '.jsp' are interpreted as jsp files.

7) For Servlets, create resin-2.0/doc/WEB-INF/classes/HelloServlet.java
   and browse http://localhost:8080/servlet/HelloServlet

   Resin automatically compiles Java classes in resin2.0/WEB-INF/classes.  
   Add the servlet source in WEB-INF/classes and browse.


IV) Plugin Configuration (unix)
-------------------------------

To install for Apache, you'll need to compile the plugin with:

  configure --with-apache=/usr/local/apache
  make
  make install

To install for Netscape, you'll need to compile the plugin with:

  configure --with-netscape=/usr/local/netscape/https-your-hostname
  make
  make install

Full details are in doc/ref/starting.xtp (or online at
http://www.caucho.com/products/resin/ref/starting.xtp).


V) Plugin Configuration (windows)
---------------------------------

To install Resin with IIS, Apache or Netscape, use

  c:\> resin2.0\bin\setup

Resin will also work with the O'Reilly WebSite.

Full details are in doc/ref/starting.xtp.


VI) XSL
-------

XSL can be run standalone as follows:

  > java com.caucho.xsl.Xsl [-xsl stylesheet] [-o dest] file1.xml file2.xml ...

By default it uses XSLT rules.  For StyleScript, add the '-stylescript'
flag.
