#echo "This script is being called $1 $2 $3 $4" >/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
. /etc/b2k/LARTIUT/FINCORE/com/commonenv.com
echo "This file is being called $1 $2" >/LAJBIUT/NAVEEN/HELP/RESIN/unlock_user/check.txt
#echo "$TBA_PROD_ROOT">>/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
sqlplus -s system/manager\@BL4UL26B:1521/$1 <<EOF
set feedback off; 
EXEC SYSTEM.sacuser('$2');
commit;
EOF
#echo "Call ended">>/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
