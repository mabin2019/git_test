#!/usr/bin/sh
CURR_DIR=/LAJBIUT/NAVEEN/HELP/RESIN/executables/generate_pstack
if [ $# != 3 ]
then
	echo " Install Id required as input. Ex: ./execute.sh <INSTALL_ID>" >$CURR_DIR/error.log
	exit
fi
cd /etc/b2k/$1/FINCORE/com 2>/dev/null
if [ $? -eq 0 ]
then
	. /etc/b2k/$1/FINCORE/com/commonenv.com
	cd $TBA_PROD_ROOT/CDCI_LOGS/$2
	name=$3
	path=`file $name | cut -d\' -f2| cut -d' ' -f1`
	`gdb $path $name < $CURR_DIR/input.txt >$TBA_PROD_ROOT/CDCI_LOGS/$2/pstack_$name`
	#`/usr/bin/gdb $path $name < $CURR_DIR/input.txt`
else
echo "The entered install id \"$1\", not existing." >$CURR_DIR/error.log
fi
