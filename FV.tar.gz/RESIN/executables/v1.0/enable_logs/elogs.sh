#!/usr/bin/sh
CURR_DIR=/LAJBIUT/NAVEEN/HELP/RESIN/executables/enable_logs
if [ $# != 2 ]
then
	echo " Install Id required as input. Ex: ./execute.sh <INSTALL_ID>" >$CURR_DIR/error.log
	exit
fi
cd /etc/b2k/$1/FINCORE/com 2>/dev/null
if [ $? -eq 0 ]
then
	. /etc/b2k/$1/FINCORE/com/commonenv.com
#	cd $TBA_PROD_ROOT/CDCI_LOGS/$2
	cp $CURR_DIR/finacle.debug $TBA_PROD_ROOT/CDCI_LOGS/$2
else
echo "The entered install id \"$1\", not existing." >$CURR_DIR/error.log
fi
