update finfadm.user_creds_tbl set USER_PW='4bf7bb316fec881a99746965c90e9b4f041eb3d5' where user_id like '461573U';
