update finfadm.user_creds_tbl set USER_PW='355487d0cc79a2d92db5e8954cb8ec91824f990d' where user_id like '461847D';
