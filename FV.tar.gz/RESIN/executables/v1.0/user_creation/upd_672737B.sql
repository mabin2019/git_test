update finfadm.user_creds_tbl set USER_PW='8e22c81d2151cb2e0dd74d17fd182ac0a1c55f8f' where user_id like '672737B';
