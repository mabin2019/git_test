update finfadm.user_creds_tbl set USER_PW='71e1b0099a08ab8a439837fe95795a84c2a6556f' where user_id like '752714S';
