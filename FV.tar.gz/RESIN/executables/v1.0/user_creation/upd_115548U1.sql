update finfadm.user_creds_tbl set USER_PW='6ba56ddde62fbff9945c8c784f1c0500df32c35d' where user_id like '115548U1';
