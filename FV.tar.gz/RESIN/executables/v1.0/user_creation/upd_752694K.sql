update finfadm.user_creds_tbl set USER_PW='90fffd8badceea7a3a9bfb0ad7d5dc9a1abf8d2a' where user_id like '752694K';
