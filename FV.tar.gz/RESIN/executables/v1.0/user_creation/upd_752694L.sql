update finfadm.user_creds_tbl set USER_PW='13e7e51930af867acd9329839fccab31556e4d1d' where user_id like '752694L';
