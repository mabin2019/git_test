update finfadm.user_creds_tbl set USER_PW='8ea87aa7083993766536301d0c8b65d4c5685ec2' where user_id like '461573';
