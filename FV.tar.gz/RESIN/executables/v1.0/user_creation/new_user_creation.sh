#echo "This script is being called $1 $2 $3 $4" >/LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/check.txt
export CLASSPATH=/LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation:$CLASSPATH
. /etc/b2k/LARTIUT/FINCORE/com/commonenv.com
#echo "$TBA_PROD_ROOT">>/LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/check.txt
/bin/java hashPwd $3 >/LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/upd_$3.sql
chmod 755 /LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/upd_$3.sql
pass=`cat /LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/upd_$3.sql| cut -d\' -f2`
sqlplus -s system/manager\@BL4UL26B:1521/$1 <<EOF
set feedback off; 
EXEC SYSTEM.USERCREATION('$2','$3','$pass','$4');
commit;
EOF
#echo "Call ended">>/LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/check.txt
rm -f /LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/upd_$3.sql
