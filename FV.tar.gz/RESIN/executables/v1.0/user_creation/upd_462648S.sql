update finfadm.user_creds_tbl set USER_PW='59c4ae8b55bb761fd040dd4569016748e7f03f8b' where user_id like '462648S';
