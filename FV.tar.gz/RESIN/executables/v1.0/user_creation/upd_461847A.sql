update finfadm.user_creds_tbl set USER_PW='f56f122f753195777b7cca161b7788f4ffc42455' where user_id like '461847A';
