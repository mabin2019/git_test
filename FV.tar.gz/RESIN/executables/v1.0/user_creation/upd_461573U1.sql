update finfadm.user_creds_tbl set USER_PW='63764e3efd137295cabadee83fef075eab3d0cd3' where user_id like '461573U1';
