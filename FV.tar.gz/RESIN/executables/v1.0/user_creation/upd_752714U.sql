update finfadm.user_creds_tbl set USER_PW='3f369d9f744cfbabc9cf2f326642f62098d3af70' where user_id like '752714U';
