update finfadm.user_creds_tbl set USER_PW='e962b6e94c66d9541c542e0430798fb8f311fd33' where user_id like '461847S';
