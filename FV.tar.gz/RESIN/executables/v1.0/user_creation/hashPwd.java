
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;

public class hashPwd{
    
    
    public static void main(String[] args) throws UnsupportedEncodingException, Exception{
        String paramString=args[0]+"/infy@123";
        @SuppressWarnings("StringBufferMayBeStringBuilder")
        StringBuffer password= new StringBuffer("infy#123");
        System.out.println("update finfadm.user_creds_tbl set USER_PW='"+getDigestToken(paramString.getBytes("UTF-8"))+"' where user_id like '"+args[0]+"';");
        //System.out.println(new String(hexStringToByteArray("0xF0")));
        
   }
   
    public static String getDigestToken(byte[] paramArrayOfByte)
    throws Exception
    {
        MessageDigest localMessageDigest = null;
    try
    {
        localMessageDigest = MessageDigest.getInstance("SHA1");
        
    }
    catch (Exception localException)
    {
        return null;
    }
    String str = getHexString(localMessageDigest.digest(paramArrayOfByte));
    
    return str;
  }
   public static final String getHexString(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null) {
      return null;
    }
    
    StringBuffer localStringBuffer = new StringBuffer(paramArrayOfByte.length * 2);
    for (int i = 0; i < paramArrayOfByte.length; i++) {
      byte2hex(paramArrayOfByte[i], localStringBuffer);
    }
    return localStringBuffer.toString();
  }
  
   public static void byte2hex(byte paramByte, StringBuffer paramStringBuffer)
  {
    char[] arrayOfChar = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
    paramStringBuffer.append(arrayOfChar[((paramByte & 0xF0) >>> 4)]);
    paramStringBuffer.append(arrayOfChar[(paramByte & 0xF)]);
  }
  
  
}

