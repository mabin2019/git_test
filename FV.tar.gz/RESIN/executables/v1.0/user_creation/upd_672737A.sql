update finfadm.user_creds_tbl set USER_PW='469bb6d1f5437366578b1c5d06c4c13e7080dd96' where user_id like '672737A';
