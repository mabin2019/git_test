update finfadm.user_creds_tbl set USER_PW='0ce1a20db9d8d6de1738e6c0b91336b7ed159a6a' where user_id like '461577US1';
