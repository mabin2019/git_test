update finfadm.user_creds_tbl set USER_PW='3e87a2acec8d362632fc5bb8fb6d44e54aad4b11' where user_id like '752694L1';
