update finfadm.user_creds_tbl set USER_PW='4539d4990f9e3aafa4c16634910bab8bad564b97' where user_id like '461573V';
