update finfadm.user_creds_tbl set USER_PW='5b66d54cf467b72304c15f6c405c5e94ab59f798' where user_id like 'DASDS';
