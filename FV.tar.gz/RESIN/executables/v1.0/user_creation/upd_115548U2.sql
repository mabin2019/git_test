update finfadm.user_creds_tbl set USER_PW='c5a433e5c1cd38689cc3c94c6f0c3ccc2ec40471' where user_id like '115548U2';
