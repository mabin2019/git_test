--Author : Deepak Srinivasa Bagade
-- Version : 1.0
--File name : Holtable.sql
--Usage : Execute this sql file in system schema or tbaadm schema for inserting holiday record in holiday_mast_table in tbaadm.schema

ALTER SESSION SET current_schema=tbaadm;
SET serveroutput on;

DECLARE
   holdate          tbaadm.holiday_mast_table.mmyyyy%TYPE;
   sol_id           tbaadm.holiday_mast_table.cal_b2k_id%TYPE;
   bank_id          tbaadm.holiday_mast_table.bank_id%TYPE;
   counter_branch   NUMBER                                      := 0;
   counter_sol      NUMBER                                      := 0;

   CURSOR branch
   IS
      SELECT   sol_id, bank_id
          FROM tbaadm.sol
      ORDER BY bank_id, sol_id;

   CURSOR dc
   IS
      SELECT   bank_id
          FROM tbaadm.gct
      ORDER BY bank_id;
BEGIN
--selecting current month and year and formatting it to Month and Year format

   SELECT LTRIM (TO_CHAR (SYSDATE, 'mmyyyy'))
     INTO holdate
     FROM DUAL;

--checks whether entry for current month is available and inserts records in HOL table for sol ids as available in SOL table.

   FOR rec IN branch
   LOOP
      SELECT COUNT (1)
        INTO counter_sol
        FROM holiday_mast_table
       WHERE bank_id = rec.bank_id
         AND cal_b2k_id = rec.sol_id
         AND mmyyyy = holdate;

      IF counter_sol != 1
      THEN
         DBMS_OUTPUT.put_line (   'the value of counter of SOL ID '
                               || rec.sol_id
                               || ' is '
                               || counter_sol
                              );

         INSERT INTO holiday_mast_table
                     (cal_b2k_type, cal_b2k_id, mmyyyy, del_flg,
                      hldy_str, comment_str, recvd_str, status,
                      lchg_user_id, lchg_time, rcre_user_id, rcre_time,
                      ts_cnt, bank_id
                     )
              VALUES ('BRANCH', rec.sol_id, holdate, 'N',
                      '                           ', NULL, NULL, NULL,
                      'UBSADMIN', SYSDATE, 'UBSADMIN', SYSDATE,
                      1, rec.bank_id
                     );

         COMMIT;
      ELSE
         DBMS_OUTPUT.put_line (   'The Value Of Counter of SOL ID '
                               || rec.sol_id
                               || ' is '
                               || counter_sol
                              );
      END IF;

      counter_sol := 0;
   END LOOP;

--checks whether entry for current month is available and inserts records in HOL table for Bank IDs as available in GCT table.

   FOR rec1 IN dc
   LOOP
      SELECT COUNT (1)
        INTO counter_branch
        FROM holiday_mast_table
       WHERE bank_id = rec1.bank_id
         AND cal_b2k_id = 'DC'
         AND mmyyyy LIKE holdate;

      IF counter_branch != 1
      THEN
         DBMS_OUTPUT.put_line (   'the value of counter for DC '
                               || rec1.bank_id
                               || ' is '
                               || counter_branch
                              );

         INSERT INTO holiday_mast_table
                     (cal_b2k_type, cal_b2k_id, mmyyyy, del_flg, hldy_str,
                      comment_str, recvd_str, status, lchg_user_id,
                      lchg_time, rcre_user_id, rcre_time, ts_cnt, bank_id
                     )
              VALUES ('DC', 'DC', holdate, 'N', NULL,
                      NULL, NULL, NULL, 'UBSADMIN',
                      SYSDATE, 'UBSADMIN', SYSDATE, 1, rec1.bank_id
                     );

         COMMIT;
         
      ELSE
         DBMS_OUTPUT.put_line (   'The Value Of Counter for DC '
                               || rec1.bank_id
                               || ' is '
                               || counter_branch
                              );
      END IF;

      counter_branch := 0;
   END LOOP;
END;
/
