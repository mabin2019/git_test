#echo "This script is being called $ORACLE_SID $2 $3 $4" >/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
cd /etc/b2k/$1/FINCORE/com
if [ $? -eq 0 ]
then
. /etc/b2k/$1/FINCORE/com/commonenv.com
#echo "This file is being called $ORACLE_SID $2" >/LAJBIUT/NAVEEN/HELP/RESIN/executables/HOLIDAY/check.txt
#echo "$TBA_PROD_ROOT">>/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
mmyyyy=`date +%m%Y`
id=`ps -ef | grep pmon | grep $ORACLE_SID`
if [ -z "$id" ]
then 
exit 2
fi
port=`tnsping $ORACLE_SID | grep $ORACLE_SID | tr -d " " | awk -F 'Port=' '{print $2}' | cut -d')' -f1`
host=`tnsping $ORACLE_SID | grep $ORACLE_SID | tr -d " " | awk -F 'Host=' '{print $2}' | cut -d')' -f1`
sqlplus -s system/manager\@$host:$port/$ORACLE_SID <<EOF1
set head off;
spool /LAJBIUT/NAVEEN/HELP/RESIN/executables/HOLIDAY/check.lst
select count(*) from tbaadm.hol where mmyyyy=${mmyyyy};
EOF1
if [ ! `cat /LAJBIUT/NAVEEN/HELP/RESIN/executables/HOLIDAY/check.lst` -gt 0 ]
then
rm -f /LAJBIUT/NAVEEN/HELP/RESIN/executables/HOLIDAY/check.lst
sqlplus -s system/manager\@$host:$port/$ORACLE_SID <<EOF
set feedback off; 
start /LAJBIUT/NAVEEN/HELP/RESIN/executables/HOLIDAY/holiday.sql
commit;
EOF
exit 0
else
rm -f /LAJBIUT/NAVEEN/HELP/RESIN/executables/HOLIDAY/check.lst
exit 1 
fi
else 
exit 3
fi
#echo "Call ended">>/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
