#echo "This script is being called $ORACLE_SID $2 $3 $4" >/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
cd /etc/b2k/$1/FINCORE/com
if [ $? -eq 0 ]
then
. /etc/b2k/$1/FINCORE/com/commonenv.com
#echo "This file is being called $ORACLE_SID $2" >/LAJBIUT/NAVEEN/HELP/RESIN/executables/unlock_user/check.txt
#echo "$TBA_PROD_ROOT">>/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
id=`ps -ef | grep pmon | grep $ORACLE_SID`
if [ -z "$id" ]
then 
exit 2
fi
port=`tnsping $ORACLE_SID | grep $ORACLE_SID | tr -d " " | awk -F 'Port=' '{print $2}' | cut -d')' -f1`
host=`tnsping $ORACLE_SID | grep $ORACLE_SID | tr -d " " | awk -F 'Host=' '{print $2}' | cut -d')' -f1`
sqlplus -s system/manager\@$host:$port/$ORACLE_SID <<EOF1
set head off;
spool /LAJBIUT/NAVEEN/HELP/RESIN/executables/unlock_user/check.lst
select count(*) from finfadm.user_creds_tbl where user_id = '$2';
EOF1
if [ `cat /LAJBIUT/NAVEEN/HELP/RESIN/executables/unlock_user/check.lst` -gt 0 ]
then
rm -f /LAJBIUT/NAVEEN/HELP/RESIN/executables/unlock_user/check.lst
sqlplus -s system/manager\@$host:$port/$ORACLE_SID <<EOF
set feedback off; 
EXEC SYSTEM.sacuser('$2');
commit;
EOF
exit 0
else
rm -f /LAJBIUT/NAVEEN/HELP/RESIN/executables/unlock_user/check.lst
exit 1 
fi
else 
exit 3
fi
#echo "Call ended">>/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
