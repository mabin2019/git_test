#echo "This script is being called $1 $2 $3 $4" >/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
. /etc/b2k/LARTIUT/FINCORE/com/commonenv.com
echo "This file is being called $1 $2" >/LAJBIUT/NAVEEN/HELP/RESIN/executables/unlock_user/check.txt
#echo "$TBA_PROD_ROOT">>/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
id=`tnsping $1 | grep $1`
if [ -z "$id" ]
then 
exit 2
fi
sqlplus -s system/manager\@BL4UL26B:1521/$1 <<EOF1
set head off;
spool /LAJBIUT/NAVEEN/HELP/RESIN/executables/unlock_user/check.lst
select count(*) from finfadm.user_creds_tbl where user_id = '$2';
EOF1
if [ `cat /LAJBIUT/NAVEEN/HELP/RESIN/executables/unlock_user/check.lst` > 0 ]
then
rm -f /LAJBIUT/NAVEEN/HELP/RESIN/executables/unlock_user/check.lst
sqlplus -s system/manager\@BL4UL26B:1521/$1 <<EOF
set feedback off; 
EXEC SYSTEM.sacuser('$2');
commit;
EOF
exit 0
else
/LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/check.lst
exit 1 
fi
#echo "Call ended">>/LAJBIUT/NAVEEN/HELP/RESIN/user_creation/check.txt
