#echo "This script is being called $ORACLE_SID $2 $3 $4" >/LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/check.txt
export CLASSPATH=/LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation:$CLASSPATH
cd /etc/b2k/$1/FINCORE/com
if [ $? -eq 0 ]
then
. /etc/b2k/$1/FINCORE/com/commonenv.com
#echo "$TBA_PROD_ROOT">>/LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/check.txt
id=`ps -ef | grep pmon | grep $ORACLE_SID`
if [ -z "$id" ]
then
exit 2
fi
port=`tnsping $ORACLE_SID | grep $ORACLE_SID | tr -d " " | awk -F 'Port=' '{print $2}' | cut -d')' -f1`
host=`tnsping $ORACLE_SID | grep $ORACLE_SID | tr -d " " | awk -F 'Host=' '{print $2}' | cut -d')' -f1`
/bin/java hashPwd $3 >/LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/upd_$3.sql
chmod 755 /LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/upd_$3.sql
pass=`cat /LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/upd_$3.sql| cut -d\' -f2`
sqlplus -s system/manager\@$host:$port/$ORACLE_SID <<EOF1
set head off;
spool /LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/check.lst;
select count(*) from finfadm.user_creds_tbl where user_id ='$2';
EOF1
if [ `cat /LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/check.lst` -gt 0 ]
then
rm -f /LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/check.lst
sqlplus -s system/manager\@$host:$port/$ORACLE_SID <<EOF
set feedback off; 
EXEC SYSTEM.USERCREATION('$2','$3','$pass','$4');
commit;
EOF
#echo "Call ended">>/LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/check.txt
rm -f /LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/upd_$3.sql
exit 0;
else
rm -f /LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/check.lst
rm -f /LAJBIUT/NAVEEN/HELP/RESIN/executables/user_creation/upd_$3.sql
exit 1 
fi
else
exit 3
fi
